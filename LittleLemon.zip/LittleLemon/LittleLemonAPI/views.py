from rest_framework import generics, mixins, viewsets
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.decorators import action, throttle_classes
from rest_framework.response import Response

from .serializers import *
from .models import *
from .throttles import *

from django.contrib.auth.models import Group, User


class UserGroupManagerView(generics.ListCreateAPIView):
    groups= Group.objects.get(name="Manager")
    queryset = User.objects.filter(groups=groups)
    serializer_class = UserSerializer
    permission_classes = [IsAdminUser]

    @action(methods=['post'], detail=True)
    def perform_create(self, serializer):
        user = serializer.save()
        group = Group.objects.get(name='Manager')
        user.groups.add(group)

class ManagerUser(generics.RetrieveDestroyAPIView):
    groups= Group.objects.get(name="Manager")
    queryset = User.objects.filter(groups=groups)
    serializer_class = UserSerializer
    permission_classes = [IsAdminUser]


class UserGroupDeliveryView(generics.ListCreateAPIView):
    groups= Group.objects.get(name="delivery_crew")
    queryset = User.objects.filter(groups=groups)
    serializer_class = UserSerializer
    permission_classes = [IsAdminUser]

    @action(methods=['post'], detail=True)
    def perform_create(self, serializer):
        user = serializer.save()
        group = Group.objects.get(name='delivery_crew')
        user.groups.add(group)

class DeliveryUser(generics.RetrieveDestroyAPIView):
    groups= Group.objects.get(name="delivery_crew")
    queryset = User.objects.filter(groups=groups)
    serializer_class = UserSerializer
    permission_classes = [IsAdminUser]

# Create your views here.
class MenuItemsView(generics.ListCreateAPIView):
    queryset = MenuItem.objects.all()
    serializer_class = MenuItemSerializer
    ordering_fields = ['title','price']
    filterset_fields = ['title', 'price']
    search_fields = ['title']

    @action(methods=['post'], detail=True, permission_classes=[IsAdminUser])
    def addItem(self, request):
        item = MenuItemSerializer(data=request.data)
        if item.is_valid():
            item.save()

class CategoryView(generics.ListCreateAPIView):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [IsAdminUser]


class SingleMenuItemView(generics.RetrieveUpdateAPIView, generics.DestroyAPIView):
    queryset = MenuItem.objects.all()
    serializer_class = MenuItemSerializer

    @action(methods=['put','patch'], detail=True, permission_classes=[IsAdminUser])
    def updateItem(self,request,pk):
        item = MenuItemSerializer.update(instance=self.queryset.get(id=pk), validated_data=request.data)
        if item.is_valid():
            item.save()

class CartView(generics.ListCreateAPIView, generics.DestroyAPIView):
    queryset = Cart.objects.all()
    serializer_class = CartSerializer
    permission_classes = [IsAuthenticated]

    @action(methods=['delete'], detail=True, permission_classes=[IsAuthenticated])
    def delete(self,request):
        delete_cart = self.queryset.filter(user = request.user)
        for item in delete_cart:
            item.delete()
        return Response( self.serializer_class(many=True).data) 

class OrderView(generics.ListCreateAPIView):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer
    permission_classes = [IsAuthenticated]
    search_fields =['user', 'delivery_crew', 'status', 'total', 'date']
    ordering_fields = ['user', 'status', 'date']
    filterset_fields = ['user', 'status', 'date']

    @action(methods=['get'], detail=True, permission_classes=[IsAuthenticated] )
    def get(self,request):
        try:
            gr = Group.objects.get(user=request.user)
            if  (gr.name == 'Manager') | (request.user.username=="admin"):
                order = self.serializer_class(instance=self.get_queryset(), many=True)
                return Response(order.data)
            elif gr.name == 'delivery_crew':
                qs = Order.objects.filter(delivery_crew=request.user)
                order = self.serializer_class(instance=qs, many= True)
                return Response(order.data)
        except:
            pass
        qs = Order.objects.filter(user=request.user)
        order = self.serializer_class(instance=qs, many= True)
        return Response(order.data)
    
@throttle_classes([TenCallsPerMinute])
class OrderItemView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer

    @action(methods=['get'], detail=True, permission_classes=[IsAuthenticated])
    def get(self, request,pk):
        qs = Order.objects.filter(id=pk)
        order = self.serializer_class(instance=qs, many= True)
        return Response(order.data)

    @action(methods=['put','patch'], detail=True, permission_classes=[IsAuthenticated])
    def update(self,request,pk):
        od = OrderSerializer(self.queryset.get(id=pk), request.data, partial=True)
        if od.is_valid():
            od.save()
        qs = Order.objects.filter(user=request.user)
        order = self.serializer_class(instance=qs, many= True)
        return Response(order.data)
            
    @action(methods=['delete'], detail=True, permission_classes=[IsAdminUser])
    def delete(self, request, *args, **kwargs):
        return super().delete(request, *args, **kwargs)