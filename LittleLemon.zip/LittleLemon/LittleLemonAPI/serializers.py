from rest_framework import serializers
from .models import *
from rest_framework.validators import UniqueTogetherValidator
from django.contrib.auth.models import Group, Permission, User

class GroupSerializer(serializers.ModelSerializer):    
    class Meta:
        model = Group
        fields = ('id', 'name',)

class UserSerializer(serializers.ModelSerializer):
    groups = GroupSerializer(many=True,read_only=True)
    class Meta:
        model = User
        fields = ['id','username', 'groups']

    def create(self, validated_data):
        user = super(UserSerializer, self).create(validated_data)
        user.save()
        return user

# Model
class CategorySerializer (serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id','slug','title']
    
    def create(self, validated_data):
        return super().create(validated_data)
    
    def update(self, instance, validated_data):
        return super().update(instance, validated_data)

class MenuItemSerializer(serializers.ModelSerializer):
    category_id = serializers.IntegerField(write_only=True)
    category = CategorySerializer(read_only=True)
    class Meta:
        model = MenuItem
        fields = ['id', 'title', 'price', 'featured', 'category', 'category_id']
        extra_kwargs = {
            'price': {'min_value': 0},
        }
    
    def create(self, validated_data):
        return MenuItem.objects.create(**validated_data)
    
    def update(self, instance, validated_data):
        # instance.title = validated_data.get('title', instance.title)
        # instance.price = validated_data.get('price', instance.price)
        # instance.featured = validated_data.get('featured', instance.featured)
        # instance.category = validated_data.get('category', instance.category)
        # return instance.save()
        return super().update(instance, validated_data)
        

class CartSerializer(serializers.ModelSerializer):
    user = serializers.PrimaryKeyRelatedField(
        queryset = User.objects.all(),
        default = serializers.CurrentUserDefault()
    )
    menuitem = MenuItemSerializer

    class Meta:
        model = Cart
        fields = ['user','menuitem', 'quantity', 'unit_price', 'price']
    
        validators = [
            UniqueTogetherValidator(
                queryset=Cart.objects.all(),
                fields=['user', 'menuitem']
            )
        ]
    
    def create(self, validated_data):
        return super().create(validated_data)
    
    def update(self, instance, validated_data):
        return super().update(instance, validated_data)

class OrderSerializer(serializers.ModelSerializer):
    user =  serializers.PrimaryKeyRelatedField(
        queryset = User.objects.all(),
        default = serializers.CurrentUserDefault()
    )

    delivery_crew = serializers.PrimaryKeyRelatedField(
        queryset = User.objects.all(),
        default = serializers.CurrentUserDefault()
    )

    class Meta:
        model = Order
        fields = ['user', 'delivery_crew', 'status', 'total', 'date']
    
    
    def create(self, validated_data):
        return super().create(validated_data)
    
    def update(self, instance, validated_data):
        return super().update(instance,validated_data)
