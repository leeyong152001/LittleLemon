from django.test import TestCase

from .models import *

# Create your tests here.
print(MenuItem.objects.all())